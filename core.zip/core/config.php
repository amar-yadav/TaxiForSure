<div align="center">

<?php
/*Configuration Settings*/

/*MySQL Settings*/
/*Database name*/
define('DB_NAME', 'forms1');

/*Database user*/
define('DB_USER', 'root');

/*Database user password*/
define('DB_PASSWORD', '');

/* Chances are you won't need to change the following three
settings. Only do so if you know what you're doing.*/

/*Database host*/
define('DB_HOST', 'localhost');

?>

</div>
