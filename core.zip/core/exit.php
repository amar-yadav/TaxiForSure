<body background = "http://7-themes.com/data_images/out/12/6809612-simple-backgrounds.jpg">
<div align="center">
<?php

header('Location: signin.php');

?>
</div>
</body>