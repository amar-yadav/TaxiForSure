<body background = "http://3.bp.blogspot.com/-fA2--xfafa8/VQsgGfkQigI/AAAAAAAAFlo/ok9uQiVw9wo/s1600/tricksfire%2Bcab%2Bbooking%2Bcoupon%2Bcodes.png">
<div align="center">
<br>
<h1>Sign in</h1>
<form action = "process0.php" method = "post"/>
<input type = "hidden" name = "formID" value = ""/>
<input type = "hidden" name = "redirect_to" value = "www.google.com"/>
<p>User Name: <input type = "text" name = "uname"></p>
<p>Password: <input type = "text" name = "pwd"></p>
<input type = "submit" value = "Sign In">
</form>
<br><br><br><br><br><br><br><br><br><br>
<h2>Check Status</h2>
<a href="checkout.php"> <h3>Go Ahead</h3> </a>
</div>
</body>