<body background = "http://7-themes.com/data_images/out/12/6809612-simple-backgrounds.jpg">
<div align="center">
<form action = "process1.php" method = "post"/>
<input type = "hidden" name = "formID" value = "form1"/>
<input type = "hidden" name = "redirect_to" value = "www.google.com"/>
<p>User Name: <input type = "text" name = "uname"></p>
<p>Password: <input type = "text" name = "pwd"></p>
<p>Name: <input type = "text" name = "name"></p>
<p>Phone No: <input type = "text" name = "no"></p>
<p>Gender: <input type = "radio" name = "sex" value = "male" checked> Male
<input type = "radio" name = "sex" value = "female"> Female <br>
<input type = "submit" value = "Submit">
</form>
</p>
</div>
</body>